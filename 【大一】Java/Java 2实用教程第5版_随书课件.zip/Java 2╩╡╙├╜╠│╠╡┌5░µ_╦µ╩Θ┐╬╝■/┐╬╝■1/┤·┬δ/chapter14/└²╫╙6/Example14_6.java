public class Example14_6 {
    public static void main(String args[]) {
        AudioClipDialog dialog=new AudioClipDialog();
        dialog.setVisible(true);
    }
}