public class Example7_1 {
   public static void main(String args[]) {
      RedCowForm form = new RedCowForm("��ţũ��");
      form.showCowMess();
      form.cow.speak();
      //RedCowForm.RedCow redCow = new RedCowForm.RedCow(180,119,6000);
      //redCow.speak();
   }   
}
