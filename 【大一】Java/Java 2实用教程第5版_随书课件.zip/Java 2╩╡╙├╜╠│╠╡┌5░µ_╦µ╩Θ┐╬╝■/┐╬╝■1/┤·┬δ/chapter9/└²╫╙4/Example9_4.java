public class Example9_4 {
   public static void main(String args[]) {
      new ShowLayout();
   }
}
