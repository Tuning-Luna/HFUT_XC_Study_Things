public class Example12_10 {
   public static void main(String args[]) {
      WindowTyped win=new WindowTyped();
      win.setTitle("����ĸ��Ϸ");
      win.setSleepTime(3000);
   }
}

