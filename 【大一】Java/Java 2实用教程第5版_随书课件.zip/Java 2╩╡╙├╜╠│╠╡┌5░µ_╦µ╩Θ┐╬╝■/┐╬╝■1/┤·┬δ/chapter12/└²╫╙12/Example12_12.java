public class Example12_12 {
   public static void main(String args[]) {
      WindowTime win=new WindowTime();
      win.setTitle("��ʱ��");
   }
}
