public class UniverStudent extends Student {
   int multi(int x,int y) {
      return x*y;
   }  
}