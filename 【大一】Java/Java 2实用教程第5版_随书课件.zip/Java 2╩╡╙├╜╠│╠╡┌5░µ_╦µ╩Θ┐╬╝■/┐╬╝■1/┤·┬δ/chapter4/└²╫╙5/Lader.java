public class Lader
{
   double above;  //���ε��ϵ�     
   double bottom;  
   double height;   
   double getArea()
   {  
      return (above+bottom)*height/2;
   }
}