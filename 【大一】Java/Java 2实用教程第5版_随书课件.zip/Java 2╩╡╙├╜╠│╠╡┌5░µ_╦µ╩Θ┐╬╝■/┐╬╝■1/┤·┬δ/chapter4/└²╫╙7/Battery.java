public class Battery {
    int electricityAmount;
    Battery(int amount){
        electricityAmount = amount;
    }
}