public class Example12_14 {
   public static void main(String args[]) {
      StandardExamInTime win=new StandardExamInTime();
      win.setTitle("��ʱ�ش�����");
      win.setTestFile(new java.io.File("test.txt"));
      win.setMAX(8); 
   }
}

