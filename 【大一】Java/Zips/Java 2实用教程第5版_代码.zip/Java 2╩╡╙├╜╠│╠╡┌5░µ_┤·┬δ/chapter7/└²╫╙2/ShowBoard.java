public class ShowBoard {
   void showMess(OutputAlphabet show) {
     show.output();   
   } 
}


