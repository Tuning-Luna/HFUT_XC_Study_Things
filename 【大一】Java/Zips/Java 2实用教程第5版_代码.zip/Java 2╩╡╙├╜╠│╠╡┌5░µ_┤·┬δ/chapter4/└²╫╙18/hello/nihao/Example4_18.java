package hello.nihao;
import sohu.com.Triangle;
public class Example4_18 { 
    public static void main(String args[]) {
        Triangle tri = new Triangle();
        tri.setSides(30,40,50);
        System.out.println(tri.getArea());
    }
}
