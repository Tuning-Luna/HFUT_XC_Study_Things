public class Example8_18 { 
   public static void main(String args[]) {
       int [] a =GetRandomNumber.getRandomNumber(100,6);
       System.out.println(java.util.Arrays.toString(a));
   }
}
