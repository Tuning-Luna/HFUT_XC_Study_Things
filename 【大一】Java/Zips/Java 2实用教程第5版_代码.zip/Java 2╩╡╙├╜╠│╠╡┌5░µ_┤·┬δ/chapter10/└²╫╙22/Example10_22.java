public class Example10_22 {
   public static void main(String args[]) {
      JDKWindow win=new JDKWindow();
   }
}