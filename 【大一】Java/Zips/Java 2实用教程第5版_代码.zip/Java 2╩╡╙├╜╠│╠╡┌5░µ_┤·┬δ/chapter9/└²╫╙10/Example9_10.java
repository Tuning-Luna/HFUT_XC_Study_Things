public class Example9_10 {
   public static void main(String args[]) {
      WindowMouse win=new WindowMouse();
      win.setTitle("��������¼�"); 
      win.setBounds(10,10,460,360);
   }
}
