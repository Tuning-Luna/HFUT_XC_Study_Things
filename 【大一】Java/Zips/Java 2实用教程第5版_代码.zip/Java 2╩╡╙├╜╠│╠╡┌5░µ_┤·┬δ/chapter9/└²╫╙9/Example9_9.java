public class Example9_9 {
   public static void main(String args[]) {
      WindowDocument win=new WindowDocument();
      win.setBounds(100,100,590,500);
      win.setTitle("���򵥴�");
   }
}
