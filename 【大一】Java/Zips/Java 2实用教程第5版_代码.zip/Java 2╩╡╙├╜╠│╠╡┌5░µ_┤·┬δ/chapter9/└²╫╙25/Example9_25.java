public class Example9_25{
   public static void main(String args[]) {
      new Hua_Rong_Road();
   }
}