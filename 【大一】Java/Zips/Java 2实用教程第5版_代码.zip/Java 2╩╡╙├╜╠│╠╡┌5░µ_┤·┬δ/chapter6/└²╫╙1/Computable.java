public interface Computable {
   int MAX = 46;
   int f(int x);
}
