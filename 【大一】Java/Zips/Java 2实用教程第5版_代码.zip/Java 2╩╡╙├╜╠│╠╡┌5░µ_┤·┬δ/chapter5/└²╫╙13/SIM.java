public abstract class SIM {
    public abstract void setNumber(String n);
    public abstract String giveNumber();
    public abstract String giveCorpName();
}

