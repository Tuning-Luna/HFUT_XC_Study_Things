public class People { 
    int age,leg = 2,hand = 2;
    protected void showPeopleMess() {
       System.out.printf("%d�꣬%dֻ��,%dֻ��\t",age,leg,hand);
    }    
}
