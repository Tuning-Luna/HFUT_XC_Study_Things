public class Example15_7 {
   public static void main(String args[]) {
      WindowWord win=new WindowWord();
      win.setTitle("Ӣ-��С�ֵ�");
   }
}
