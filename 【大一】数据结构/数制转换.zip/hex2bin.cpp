#include<bits/stdc++.h> 	//16����ת2���ƣ�ȥǰ��0 
using namespace std;
int main(){ 
	string hexs,bins="";
	cin>>hexs;	//����16�������� 
	char x;
	for(int i=0;i<hexs.size();i++)
	{
		x=hexs[i];
		switch(x)
		{
			case '0':bins+="0000";break;
			case '1':bins+="0001";break;
			case '2':bins+="0010";break;
			case '3':bins+="0011";break;
			case '4':bins+="0100";break;
			case '5':bins+="0101";break;
			case '6':bins+="0110";break;
			case '7':bins+="0111";break;
			case '8':bins+="1000";break;
			case '9':bins+="1001";break;
			case 'A':bins+="1010";break;
			case 'B':bins+="1011";break;
			case 'C':bins+="1100";break;
			case 'D':bins+="1101";break;
			case 'E':bins+="1110";break;
			case 'F':bins+="1111";break;
			case '.':bins+=".";break;	//С���� 
		}
	}
	int n=bins.find('1');
	bins.erase(0,n);  //ɾ��ǰ��0
	cout<<bins<<endl;
}
