#include<bits/stdc++.h> 	//16����ת10���� 
using namespace std;
int main(){ 
	string hexs,zs,xs,decs="";
	string hex="0123456789ABCDEF";	//16��������
	float t=0;
	cin>>hexs;	//����16�������� 
	int n;
	if((n=hexs.find('.'))!=string::npos){
		zs=hexs.substr(0,n);
		xs=hexs.substr(n+1);
	}else{
		zs=hexs;
		xs="";
	}	
	for(int i=0;i<zs.size();i++)		
		t=t*16+hex.find(zs[i]);
	if(xs.size()>0){
		for(int i=0;i<xs.size();i++)
			t+=hex.find(xs[i])/pow(16,i+1);
	}
	if(xs.size()>0)	
		cout<<fixed<<setprecision(3)<<t<<endl;
	else
		cout<<(int)t<<endl;
}
