
char A[100];
int k=0;

void findPath(btNode *T)
{
	if(T)
	{
	cout<<T->data<<" �������·��Ϊ��";
	A[k++]=T->data;

	for(int j=k-1;j>=0;j--)
	{
		cout<<A[j]<<"\t";	
	}
	cout<<endl;
	findPath(T->lChild);
	findPath(T->rChild);
	k--;
	}
}

void find(btNode *T,char A[],int &m)
{
	if(T)
	{
	cout<<T->data<<" �������·��Ϊ��";
	A[m++]=T->data;

	for(int j=m-1;j>=0;j--)
	{
		cout<<A[j]<<"\t";	
	}
	cout<<endl;
	find(T->lChild,A,m);
	find(T->rChild,A,m);
	m--;
	}
}