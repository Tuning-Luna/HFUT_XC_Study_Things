// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__8ED1A320_B54B_4D4A_BE08_A29072F2A1D6__INCLUDED_)
#define AFX_STDAFX_H__8ED1A320_B54B_4D4A_BE08_A29072F2A1D6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__8ED1A320_B54B_4D4A_BE08_A29072F2A1D6__INCLUDED_)
