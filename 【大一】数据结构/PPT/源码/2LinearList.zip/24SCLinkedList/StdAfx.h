// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__9B96F0DB_6412_47E0_B4B0_6CF2B1C3B514__INCLUDED_)
#define AFX_STDAFX_H__9B96F0DB_6412_47E0_B4B0_6CF2B1C3B514__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__9B96F0DB_6412_47E0_B4B0_6CF2B1C3B514__INCLUDED_)
