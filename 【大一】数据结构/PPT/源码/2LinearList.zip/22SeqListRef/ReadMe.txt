========================================================================
       CONSOLE APPLICATION : 22SeqListRef
========================================================================


AppWizard has created this 22SeqListRef application for you.  

This file contains a summary of what you will find in each of the files that
make up your 22SeqListRef application.

22SeqListRef.dsp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.dsp) file, but they should export the makefiles locally.

22SeqListRef.cpp
    This is the main application source file.


/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named 22SeqListRef.pch and a precompiled types file named StdAfx.obj.


/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
